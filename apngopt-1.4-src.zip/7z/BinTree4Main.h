#ifndef __BINTREEMAIN4__H
#define __BINTREEMAIN4__H

#undef BT_CLSID
#define BT_CLSID CLSID_CMatchFinderBT4

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT4

#define HASH_ARRAY_2
#define HASH_ARRAY_3

#include "BinTreeMFMain.h"

#undef HASH_ARRAY_2
#undef HASH_ARRAY_3

#endif

